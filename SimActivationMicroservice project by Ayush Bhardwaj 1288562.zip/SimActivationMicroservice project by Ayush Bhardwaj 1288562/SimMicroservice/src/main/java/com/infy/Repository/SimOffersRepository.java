package com.infy.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infy.Entity.SimOffers;

public interface SimOffersRepository extends JpaRepository<SimOffers, Integer>{			//creating the jpa repository interface for sim offers repository

	List<SimOffers> findBySimId(Integer simId);
}
